# Basketball Austria App — Interaktiver MVP Pitch-Prototyp

Ein Flutter-Prototyp für eine zentrale österreichische Basketball-Plattform
(1. Bundesliga Herren, 2. Bundesliga Herren, Damen Bundesliga). Gebaut für
Pitches bei Basketball Austria, Vereinen und Sponsoren.

⚠️ **Ausschließlich Mock-Daten.** Kein Backend, keine Authentifizierung,
keine echten APIs. Alle Teams, Spieler und News sind frei erfunden.

## Setup

```bash
flutter pub get
flutter run
```

Getestet mit Flutter 3.22+ / Dart 3.4+. Material 3, dunkles Theme.

## Projektstruktur

```
lib/
  main.dart                     Einstiegspunkt
  theme/app_theme.dart          Farben (#0B0F19 / #FF8A00), Typografie, Schatten
  models/models.dart            Team, Player, Game, NewsArticle, TableRow
  data/mock_data.dart           Alle Mock-Daten (Teams, Spieler, Spiele, News)
  widgets/widgets.dart          Wiederverwendbare Komponenten
                                 (TeamLogo, PlayerAvatar, GameCard, NewsCard,
                                  PlayerCard, TableRowWidget, StatTile, LiveBadge)
  screens/
    splash_screen.dart          1. Splash Screen mit Basketball-Animation
    main_navigation.dart        Bottom Navigation Host
    home_screen.dart            2. Home Screen (Hero, Live, News, Top Performer)
    ligen_screen.dart           3. Ligen Screen (3 Tabs, Tabellen)
    spielplan_screen.dart       4. Spielplan Screen (Heute/Woche/Playoffs)
    live_game_screen.dart       5. Live Game Screen (Score, Quarter, Stats)
    team_profile_screen.dart    6. Team Profile (Übersicht/Spielplan/Kader/Stats)
    player_profile_screen.dart  7. Player Profile (Stats + Saisonverlauf-Chart)
    news_screen.dart            8. News Screen
    favoriten_screen.dart       9. Favoriten Screen (Personalisierung)
```

## Bottom Navigation

Home · Live · Ligen · News · Profil

Der Spielplan-Screen ist über den Kalender-Button im Ligen-Header sowie
über "Live verfolgen" / Live-Karten erreichbar.

## Design

- Dunkler Hintergrund `#0B0F19`, Akzent Orange/Gold `#FF8A00`
- Karten mit Schatten (`cardShadow` in `app_theme.dart`)
- Google Fonts (Manrope) für klare, moderne Typografie
- Sanfte Animationen: Splash-Bounce, Live-Pulsieren, Screen-Fade

## Nächste Schritte für Produktivbetrieb

- Anbindung an echte Basketball Austria / Vereins-Daten (API)
- Push-Benachrichtigungen für Favoriten
- Echtes Live-Score-Feed statt Mock-Daten
- Login & Nutzerprofile
