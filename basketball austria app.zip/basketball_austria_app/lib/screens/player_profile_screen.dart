import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../widgets/widgets.dart';
import 'team_profile_screen.dart';

class PlayerProfileScreen extends StatelessWidget {
  final Player player;
  const PlayerProfileScreen({super.key, required this.player});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 130),
          children: [
            Row(
              children: [
                IconButton(icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18), onPressed: () => Navigator.pop(context)),
              ],
            ),
            const SizedBox(height: 8),
            Center(
              child: Column(
                children: [
                  PlayerAvatar(player: player, size: 100),
                  const SizedBox(height: 16),
                  Text(player.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 6),
                  InkWell(
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TeamProfileScreen(team: player.team))),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TeamLogo(team: player.team, size: 22),
                        const SizedBox(width: 6),
                        Text(player.team.name, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20)),
                    child: Text('${player.position} · #${player.nummer}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 28),
            const Text('Saison-Statistiken', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.5,
              children: [
                StatTile(value: player.ppg.toStringAsFixed(1), label: 'PPG'),
                StatTile(value: player.rpg.toStringAsFixed(1), label: 'RPG'),
                StatTile(value: player.apg.toStringAsFixed(1), label: 'APG'),
                StatTile(value: '${player.fgPercent.toStringAsFixed(1)}%', label: 'FG%'),
                StatTile(value: player.minutes.toStringAsFixed(1), label: 'Minuten'),
                StatTile(value: '#${player.nummer}', label: 'Trikot'),
              ],
            ),
            const SizedBox(height: 28),
            const Text('Saisonverlauf (Punkte)', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),
            Container(
              height: 220,
              padding: const EdgeInsets.fromLTRB(12, 20, 20, 12),
              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), boxShadow: cardShadow),
              child: LineChart(
                LineChartData(
                  gridData: FlGridData(
                    show: true,
                    drawVerticalLine: false,
                    getDrawingHorizontalLine: (_) => FlLine(color: AppColors.divider, strokeWidth: 1),
                  ),
                  titlesData: FlTitlesData(
                    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 30,
                        getTitlesWidget: (value, meta) => Text('${value.toInt()}', style: const TextStyle(color: AppColors.textSecondary, fontSize: 10)),
                      ),
                    ),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) => Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Text('${value.toInt() + 1}', style: const TextStyle(color: AppColors.textSecondary, fontSize: 10)),
                        ),
                      ),
                    ),
                  ),
                  borderData: FlBorderData(show: false),
                  lineBarsData: [
                    LineChartBarData(
                      spots: [
                        for (int i = 0; i < player.saisonverlauf.length; i++) FlSpot(i.toDouble(), player.saisonverlauf[i]),
                      ],
                      isCurved: true,
                      color: AppColors.accent,
                      barWidth: 3,
                      dotData: const FlDotData(show: false),
                      belowBarData: BarAreaData(
                        show: true,
                        gradient: LinearGradient(
                          colors: [AppColors.accent.withValues(alpha: 0.35), AppColors.accent.withValues(alpha: 0.0)],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
