import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../widgets/widgets.dart';
import 'team_profile_screen.dart';
import 'spielplan_screen.dart';

class LigenScreen extends StatefulWidget {
  const LigenScreen({super.key});
  @override
  State<LigenScreen> createState() => _LigenScreenState();
}

class _LigenScreenState extends State<LigenScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController = TabController(length: 3, vsync: this);
  final List<Liga> _ligen = const [Liga.herren1, Liga.herren2, Liga.damen];

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Ligen', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
                InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SpielplanScreen())),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14)),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.calendar_month_rounded, size: 16, color: AppColors.accent),
                        SizedBox(width: 6),
                        Text('Spielplan', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Container(
              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16)),
              child: TabBar(
                controller: _tabController,
                indicator: BoxDecoration(
                  color: AppColors.accent,
                  borderRadius: BorderRadius.circular(14),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                indicatorPadding: const EdgeInsets.all(4),
                labelColor: Colors.black,
                unselectedLabelColor: AppColors.textSecondary,
                labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
                dividerColor: Colors.transparent,
                tabs: const [
                  Tab(text: '1. Bundesliga'),
                  Tab(text: '2. Bundesliga'),
                  Tab(text: 'Damen'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: _ligen.map((liga) => _TabelleView(liga: liga)).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class _TabelleView extends StatelessWidget {
  final Liga liga;
  const _TabelleView({required this.liga});

  @override
  Widget build(BuildContext context) {
    final tabelle = MockData.tabelle(liga);
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 130),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), boxShadow: cardShadow),
          child: Column(
            children: [
              Row(
                children: const [
                  SizedBox(width: 24),
                  SizedBox(width: 8),
                  SizedBox(width: 32),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text('Team', style: TextStyle(color: AppColors.textSecondary, fontSize: 11, fontWeight: FontWeight.w700)),
                  ),
                  SizedBox(width: 28, child: Text('Sp', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 11))),
                  SizedBox(width: 28, child: Text('S', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 11))),
                  SizedBox(width: 28, child: Text('N', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 11))),
                  SizedBox(width: 32, child: Text('Pkt', textAlign: TextAlign.right, style: TextStyle(color: AppColors.textSecondary, fontSize: 11))),
                ],
              ),
              const Divider(height: 20),
              ...tabelle.map(
                (row) => TableRowWidget(
                  row: row,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => TeamProfileScreen(team: row.team)),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'Die Top 4 Teams (markiert) qualifizieren sich direkt für die Playoffs.',
          style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
        ),
      ],
    );
  }
}
