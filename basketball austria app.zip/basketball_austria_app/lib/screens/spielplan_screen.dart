import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../widgets/widgets.dart';
import 'live_game_screen.dart';

class SpielplanScreen extends StatefulWidget {
  const SpielplanScreen({super.key});
  @override
  State<SpielplanScreen> createState() => _SpielplanScreenState();
}

class _SpielplanScreenState extends State<SpielplanScreen> {
  int _filter = 0; // 0 = Heute, 1 = Diese Woche, 2 = Playoffs
  final List<String> _labels = const ['Heute', 'Diese Woche', 'Playoffs'];

  List<Game> get _gefiltert {
    final now = DateTime.now();
    switch (_filter) {
      case 0:
        return MockData.alleSpiele.where((g) => g.datum.day == now.day && g.datum.month == now.month).toList();
      case 1:
        return MockData.alleSpiele.where((g) => g.datum.difference(now).inDays.abs() <= 7).toList();
      case 2:
        return MockData.alleSpiele.where((g) => g.datum.difference(now).inDays >= 10).toList();
      default:
        return MockData.alleSpiele;
    }
  }

  @override
  Widget build(BuildContext context) {
    final spiele = _gefiltert;
    return SafeArea(
      child: Column(
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 12, 20, 8),
            child: Row(children: [Text('Spielplan', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900))]),
          ),
          SizedBox(
            height: 44,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              scrollDirection: Axis.horizontal,
              itemCount: _labels.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (context, i) {
                final selected = _filter == i;
                return ChoiceChip(
                  label: Text(_labels[i]),
                  selected: selected,
                  onSelected: (_) => setState(() => _filter = i),
                  backgroundColor: AppColors.surface,
                  selectedColor: AppColors.accent,
                  labelStyle: TextStyle(
                    color: selected ? Colors.black : AppColors.textSecondary,
                    fontWeight: FontWeight.w700,
                  ),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide.none),
                );
              },
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: spiele.isEmpty
                ? const Center(
                    child: Text('Keine Spiele in diesem Zeitraum', style: TextStyle(color: AppColors.textSecondary)),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 130),
                    itemCount: spiele.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 14),
                    itemBuilder: (context, i) {
                      final game = spiele[i];
                      return GameCard(
                        game: game,
                        onTap: game.status == GameStatus.live
                            ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => LiveGameScreen(game: game)))
                            : null,
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
