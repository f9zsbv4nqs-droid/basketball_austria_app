import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../widgets/widgets.dart';
import 'live_game_screen.dart';
import 'news_screen.dart';
import 'player_profile_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Duration _remaining = const Duration();
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _updateCountdown();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _updateCountdown());
  }

  void _updateCountdown() {
    final diff = MockData.topSpielHeute.datum.difference(DateTime.now());
    setState(() => _remaining = diff.isNegative ? Duration.zero : diff);
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String _fmt(Duration d) {
    final h = d.inHours.toString().padLeft(2, '0');
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final game = MockData.topSpielHeute;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 130),
        children: [
          // ---------------- HEADER ----------------
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      gradient: AppColors.accentGradient,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    alignment: Alignment.center,
                    child: const Icon(Icons.sports_basketball, color: Colors.black, size: 20),
                  ),
                  const SizedBox(width: 10),
                  const Text('Basketball Austria', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                ],
              ),
              Row(
                children: [
                  _iconButton(Icons.notifications_none_rounded, badge: true),
                  const SizedBox(width: 10),
                  _iconButton(Icons.person_outline_rounded),
                ],
              ),
            ],
          ),
          const SizedBox(height: 22),

          // ---------------- HERO BEREICH ----------------
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: AppColors.heroGradient,
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: AppColors.divider),
              boxShadow: cardShadow,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: AppColors.accent.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Text(
                        'win2day Basketball Superliga',
                        style: TextStyle(color: AppColors.accent, fontWeight: FontWeight.w700, fontSize: 11),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _heroTeam(game.heim),
                    Column(
                      children: [
                        const Text('TOP SPIEL', style: TextStyle(color: AppColors.textSecondary, fontSize: 10, letterSpacing: 1)),
                        const SizedBox(height: 6),
                        Text(
                          _fmt(_remaining),
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, fontFeatures: [FontFeature.tabularFigures()]),
                        ),
                        const SizedBox(height: 2),
                        const Text('bis Tip-off', style: TextStyle(color: AppColors.textSecondary, fontSize: 10)),
                      ],
                    ),
                    _heroTeam(game.gast),
                  ],
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => LiveGameScreen(game: MockData.liveSpiel)),
                    ),
                    icon: const Icon(Icons.play_circle_fill_rounded, size: 20),
                    label: const Text('Live verfolgen'),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 28),

          // ---------------- LIVE ----------------
          SectionHeader(title: 'Live', actionLabel: 'Alle', onAction: () {}),
          const SizedBox(height: 14),
          GameCard(
            game: MockData.liveSpiel,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => LiveGameScreen(game: MockData.liveSpiel)),
            ),
          ),

          const SizedBox(height: 28),

          // ---------------- NEWS ----------------
          SectionHeader(
            title: 'News',
            actionLabel: 'Alle',
            onAction: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NewsScreen())),
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 190,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: 3,
              separatorBuilder: (_, __) => const SizedBox(width: 14),
              itemBuilder: (_, i) => SizedBox(
                width: 280,
                child: NewsCard(article: MockData.news[i]),
              ),
            ),
          ),

          const SizedBox(height: 28),

          // ---------------- TOP PERFORMER ----------------
          const SectionHeader(title: 'Top Performer'),
          const SizedBox(height: 14),
          SizedBox(
            height: 168,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: MockData.topPerformer().length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (_, i) {
                final player = MockData.topPerformer()[i];
                return PlayerCard(
                  player: player,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => PlayerProfileScreen(player: player)),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _heroTeam(Team team) {
    return Column(
      children: [
        TeamLogo(team: team, size: 54),
        const SizedBox(height: 8),
        SizedBox(
          width: 84,
          child: Text(
            team.name,
            textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  Widget _iconButton(IconData icon, {bool badge = false}) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, size: 20),
        ),
        if (badge)
          Positioned(
            top: 8,
            right: 8,
            child: Container(
              width: 8,
              height: 8,
              decoration: const BoxDecoration(color: AppColors.accent, shape: BoxShape.circle),
            ),
          ),
      ],
    );
  }
}
