import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../widgets/widgets.dart';
import 'player_profile_screen.dart';

class TeamProfileScreen extends StatefulWidget {
  final Team team;
  const TeamProfileScreen({super.key, required this.team});

  @override
  State<TeamProfileScreen> createState() => _TeamProfileScreenState();
}

class _TeamProfileScreenState extends State<TeamProfileScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController = TabController(length: 4, vsync: this);

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final team = widget.team;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 20, 8),
              child: Row(
                children: [
                  IconButton(icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18), onPressed: () => Navigator.pop(context)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  TeamLogo(team: team, size: 84),
                  const SizedBox(height: 14),
                  Text(team.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900), textAlign: TextAlign.center),
                  const SizedBox(height: 4),
                  Text(team.liga.label, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      Expanded(child: _infoBox(Icons.stadium_rounded, 'Arena', team.arena)),
                      const SizedBox(width: 10),
                      Expanded(child: _infoBox(Icons.person_rounded, 'Trainer', team.trainer)),
                      const SizedBox(width: 10),
                      Expanded(child: _infoBox(Icons.leaderboard_rounded, 'Platz', '${team.tabellenplatz}.')),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Container(
                decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16)),
                child: TabBar(
                  controller: _tabController,
                  indicator: BoxDecoration(color: AppColors.accent, borderRadius: BorderRadius.circular(14)),
                  indicatorSize: TabBarIndicatorSize.tab,
                  indicatorPadding: const EdgeInsets.all(4),
                  labelColor: Colors.black,
                  unselectedLabelColor: AppColors.textSecondary,
                  labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 11),
                  dividerColor: Colors.transparent,
                  tabs: const [
                    Tab(text: 'Übersicht'),
                    Tab(text: 'Spielplan'),
                    Tab(text: 'Kader'),
                    Tab(text: 'Statistik'),
                  ],
                ),
              ),
            ),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _uebersichtTab(team),
                  _spielplanTab(team),
                  _kaderTab(team),
                  _statistikTab(team),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoBox(IconData icon, String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14)),
      child: Column(
        children: [
          Icon(icon, color: AppColors.accent, size: 18),
          const SizedBox(height: 6),
          Text(label, style: const TextStyle(fontSize: 10, color: AppColors.textSecondary)),
          const SizedBox(height: 2),
          Text(value, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700), textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }

  Widget _uebersichtTab(Team team) {
    final spiele = MockData.spielplanVonTeam(team);
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 130),
      children: [
        const Text('Letzte & nächste Spiele', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        const SizedBox(height: 12),
        ...spiele.map((g) => Padding(padding: const EdgeInsets.only(bottom: 12), child: GameCard(game: g))),
        if (spiele.isEmpty) const Text('Keine Spiele verfügbar.', style: TextStyle(color: AppColors.textSecondary)),
      ],
    );
  }

  Widget _spielplanTab(Team team) {
    final spiele = MockData.spielplanVonTeam(team);
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 130),
      itemCount: spiele.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, i) => GameCard(game: spiele[i]),
    );
  }

  Widget _kaderTab(Team team) {
    final spieler = MockData.spielerVonTeam(team);
    final anzeige = spieler.isEmpty ? MockData.alleSpieler.take(3).toList() : spieler;
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 130),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 14,
        crossAxisSpacing: 14,
        childAspectRatio: 0.78,
      ),
      itemCount: anzeige.length,
      itemBuilder: (context, i) {
        final p = anzeige[i];
        return InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerProfileScreen(player: p))),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(18), boxShadow: cardShadow),
            child: Column(
              children: [
                PlayerAvatar(player: p, size: 60),
                const SizedBox(height: 10),
                Text(p.name, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                Text(p.position, style: const TextStyle(color: AppColors.textSecondary, fontSize: 11)),
                const Spacer(),
                Text('${p.ppg.toStringAsFixed(1)} PPG', style: const TextStyle(color: AppColors.accent, fontWeight: FontWeight.w800, fontSize: 13)),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _statistikTab(Team team) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 130),
      children: [
        Row(
          children: [
            Expanded(child: StatTile(value: '${team.tabellenplatz}.', label: 'Tabellenplatz')),
            const SizedBox(width: 12),
            const Expanded(child: StatTile(value: '91.4', label: 'PTS/Spiel')),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: const [
            Expanded(child: StatTile(value: '42.1', label: 'REB/Spiel')),
            SizedBox(width: 12),
            Expanded(child: StatTile(value: '22.7', label: 'AST/Spiel')),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: const [
            Expanded(child: StatTile(value: '48.6%', label: 'FG%')),
            SizedBox(width: 12),
            Expanded(child: StatTile(value: '35.2%', label: '3PT%')),
          ],
        ),
      ],
    );
  }
}
