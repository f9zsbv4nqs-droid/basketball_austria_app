import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../widgets/widgets.dart';

class LiveGameScreen extends StatelessWidget {
  final Game game;
  const LiveGameScreen({super.key, required this.game});

  @override
  Widget build(BuildContext context) {
    final topScorerHeim = MockData.spielerVonTeam(game.heim).isNotEmpty
        ? MockData.spielerVonTeam(game.heim).first
        : MockData.lukasHofmann;
    final topScorerGast = MockData.spielerVonTeam(game.gast).isNotEmpty
        ? MockData.spielerVonTeam(game.gast).first
        : MockData.marcusJefferson;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 130),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Live-Spiel', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
              if (game.status == GameStatus.live) const LiveBadge(),
            ],
          ),
          const SizedBox(height: 6),
          Text(game.halle, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
          const SizedBox(height: 20),

          // ---------------- SCORE BEREICH ----------------
          Container(
            padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 16),
            decoration: BoxDecoration(
              gradient: AppColors.heroGradient,
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: AppColors.divider),
              boxShadow: cardShadow,
            ),
            child: Column(
              children: [
                if (game.status == GameStatus.live)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(color: AppColors.accent.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(20)),
                    child: Text(game.quarter, style: const TextStyle(color: AppColors.accent, fontWeight: FontWeight.w800, fontSize: 13)),
                  ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _teamScoreColumn(game.heim, game.heimScore),
                    Column(
                      children: const [
                        Text('—', style: TextStyle(fontSize: 24, color: AppColors.textSecondary)),
                      ],
                    ),
                    _teamScoreColumn(game.gast, game.gastScore),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 26),

          // ---------------- SPIELVERLAUF ----------------
          const Text('Spielverlauf', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), boxShadow: cardShadow),
            child: Column(
              children: [
                _quarterHeaderRow(),
                const Divider(height: 22),
                _quarterScoreRow(game.heim.kurzname, game.heimQuarterScores, game.heimScore, isHeim: true),
                const SizedBox(height: 10),
                _quarterScoreRow(game.gast.kurzname, game.gastQuarterScores, game.gastScore, isHeim: false),
              ],
            ),
          ),

          const SizedBox(height: 26),

          // ---------------- STATISTIKEN ----------------
          const Text('Statistiken', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          _statComparisonCard(
            title: 'Top Scorer',
            heimLabel: topScorerHeim.name,
            heimValue: topScorerHeim.ppg.toStringAsFixed(0),
            gastLabel: topScorerGast.name,
            gastValue: topScorerGast.ppg.toStringAsFixed(0),
          ),
          const SizedBox(height: 12),
          _statComparisonCard(
            title: 'Rebounds',
            heimLabel: game.heim.kurzname,
            heimValue: '39',
            gastLabel: game.gast.kurzname,
            gastValue: '34',
          ),
          const SizedBox(height: 12),
          _statComparisonCard(
            title: 'Assists',
            heimLabel: game.heim.kurzname,
            heimValue: '21',
            gastLabel: game.gast.kurzname,
            gastValue: '18',
          ),
        ],
      ),
    );
  }

  Widget _teamScoreColumn(Team team, int score) {
    return Column(
      children: [
        TeamLogo(team: team, size: 60),
        const SizedBox(height: 10),
        SizedBox(
          width: 90,
          child: Text(team.name, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
        ),
        const SizedBox(height: 8),
        Text('$score', style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w900)),
      ],
    );
  }

  Widget _quarterHeaderRow() {
    return Row(
      children: const [
        SizedBox(width: 50),
        Expanded(child: Text('Q1', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 12))),
        Expanded(child: Text('Q2', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 12))),
        Expanded(child: Text('Q3', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 12))),
        Expanded(child: Text('Q4', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 12))),
        SizedBox(width: 40, child: Text('Ges.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 12))),
      ],
    );
  }

  Widget _quarterScoreRow(String label, List<int> scores, int total, {required bool isHeim}) {
    final filled = List<int>.from(scores);
    while (filled.length < 4) {
      filled.add(0);
    }
    return Row(
      children: [
        SizedBox(width: 50, child: Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13))),
        ...filled.map((q) => Expanded(child: Text('$q', textAlign: TextAlign.center, style: const TextStyle(fontSize: 13)))),
        SizedBox(width: 40, child: Text('$total', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.accent))),
      ],
    );
  }

  Widget _statComparisonCard({
    required String title,
    required String heimLabel,
    required String heimValue,
    required String gastLabel,
    required String gastValue,
  }) {
    final hv = double.tryParse(heimValue) ?? 1;
    final gv = double.tryParse(gastValue) ?? 1;
    final total = (hv + gv) == 0 ? 1 : (hv + gv);
    final heimRatio = hv / total;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(18), boxShadow: cardShadow),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(child: Text(heimLabel, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13), overflow: TextOverflow.ellipsis)),
              Text(heimValue, style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.accent)),
              const SizedBox(width: 10),
              Text(gastValue, style: const TextStyle(fontWeight: FontWeight.w800)),
              Expanded(
                child: Text(gastLabel, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13), overflow: TextOverflow.ellipsis),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: SizedBox(
              height: 8,
              child: Row(
                children: [
                  Expanded(flex: (heimRatio * 100).round().clamp(1, 99), child: Container(color: AppColors.accent)),
                  Expanded(flex: (100 - (heimRatio * 100).round()).clamp(1, 99), child: Container(color: AppColors.divider)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
