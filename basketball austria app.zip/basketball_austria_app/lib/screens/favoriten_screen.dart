import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../widgets/widgets.dart';
import 'team_profile_screen.dart';
import 'player_profile_screen.dart';

class FavoritenScreen extends StatefulWidget {
  const FavoritenScreen({super.key});
  @override
  State<FavoritenScreen> createState() => _FavoritenScreenState();
}

class _FavoritenScreenState extends State<FavoritenScreen> {
  Team? _lieblingsverein;
  Player? _lieblingsspieler;

  bool get _istPersonalisiert => _lieblingsverein != null && _lieblingsspieler != null;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 130),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Profil', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14)),
                child: const Icon(Icons.settings_outlined, size: 20),
              ),
            ],
          ),
          const SizedBox(height: 20),

          if (_istPersonalisiert) _personalisierteAnsicht() else _auswahlAnsicht(),
        ],
      ),
    );
  }

  Widget _auswahlAnsicht() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), boxShadow: cardShadow),
          child: Row(
            children: [
              const Icon(Icons.favorite_rounded, color: AppColors.accent),
              const SizedBox(width: 12),
              const Expanded(
                child: Text(
                  'Wähle deinen Lieblingsverein und -spieler für eine personalisierte Startseite.',
                  style: TextStyle(fontSize: 13, color: AppColors.textSecondary),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        const Text('Lieblingsverein', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        const SizedBox(height: 12),
        SizedBox(
          height: 100,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: MockData.alleTeams.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, i) {
              final team = MockData.alleTeams[i];
              final selected = _lieblingsverein?.id == team.id;
              return GestureDetector(
                onTap: () => setState(() => _lieblingsverein = team),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: selected ? AppColors.accent : Colors.transparent, width: 2),
                      ),
                      child: TeamLogo(team: team, size: 54),
                    ),
                    const SizedBox(height: 6),
                    SizedBox(
                      width: 64,
                      child: Text(team.kurzname, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11)),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 24),
        const Text('Lieblingsspieler', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        const SizedBox(height: 12),
        SizedBox(
          height: 168,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: MockData.alleSpieler.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, i) {
              final player = MockData.alleSpieler[i];
              final selected = _lieblingsspieler?.id == player.id;
              return Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: selected ? AppColors.accent : Colors.transparent, width: 2),
                ),
                child: PlayerCard(player: player, onTap: () => setState(() => _lieblingsspieler = player)),
              );
            },
          ),
        ),
        const SizedBox(height: 28),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: (_lieblingsverein != null && _lieblingsspieler != null) ? () => setState(() {}) : null,
            child: const Text('Startseite personalisieren'),
          ),
        ),
      ],
    );
  }

  Widget _personalisierteAnsicht() {
    final team = _lieblingsverein!;
    final player = _lieblingsspieler!;
    final naechstesSpiel = MockData.spielplanVonTeam(team).isNotEmpty ? MockData.spielplanVonTeam(team).first : null;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: AppColors.accentGradient,
            borderRadius: BorderRadius.circular(24),
            boxShadow: cardShadow,
          ),
          child: Row(
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: const BoxDecoration(color: Colors.black26, shape: BoxShape.circle),
                alignment: Alignment.center,
                child: const Icon(Icons.person_rounded, color: Colors.black, size: 30),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Dein Basketball-Feed', style: TextStyle(color: Colors.black, fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 4),
                    Text('${team.name} · ${player.name}', style: const TextStyle(color: Colors.black87, fontSize: 12)),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const Text('Dein Verein', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        const SizedBox(height: 12),
        InkWell(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TeamProfileScreen(team: team))),
          borderRadius: BorderRadius.circular(18),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(18), boxShadow: cardShadow),
            child: Row(
              children: [
                TeamLogo(team: team, size: 48),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(team.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                      Text('Tabellenplatz ${team.tabellenplatz} · ${team.liga.label}', style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right_rounded, color: AppColors.textSecondary),
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),
        const Text('Dein Spieler', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        const SizedBox(height: 12),
        InkWell(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerProfileScreen(player: player))),
          borderRadius: BorderRadius.circular(18),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(18), boxShadow: cardShadow),
            child: Row(
              children: [
                PlayerAvatar(player: player, size: 48),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(player.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                      Text('${player.ppg.toStringAsFixed(1)} PPG · ${player.position}', style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right_rounded, color: AppColors.textSecondary),
              ],
            ),
          ),
        ),
        if (naechstesSpiel != null) ...[
          const SizedBox(height: 20),
          const Text('Nächstes Spiel', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 12),
          GameCard(game: naechstesSpiel),
        ],
        const SizedBox(height: 22),
        Center(
          child: TextButton(
            onPressed: () => setState(() {
              _lieblingsverein = null;
              _lieblingsspieler = null;
            }),
            child: const Text('Auswahl ändern', style: TextStyle(color: AppColors.textSecondary)),
          ),
        ),
      ],
    );
  }
}
