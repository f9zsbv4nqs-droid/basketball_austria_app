import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'main_navigation.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1800),
  );

  late final Animation<double> _bounce = TweenSequence([
    TweenSequenceItem(tween: Tween(begin: -160.0, end: 0.0).chain(CurveTween(curve: Curves.easeOutBack)), weight: 45),
    TweenSequenceItem(tween: Tween(begin: 0.0, end: -18.0).chain(CurveTween(curve: Curves.easeOut)), weight: 12),
    TweenSequenceItem(tween: Tween(begin: -18.0, end: 0.0).chain(CurveTween(curve: Curves.bounceOut)), weight: 13),
  ]).animate(_controller);

  late final Animation<double> _rotate = Tween<double>(begin: -0.6, end: 0.0)
      .animate(CurvedAnimation(parent: _controller, curve: const Interval(0.0, 0.6, curve: Curves.easeOut)));

  late final Animation<double> _fadeText = CurvedAnimation(
    parent: _controller,
    curve: const Interval(0.55, 1.0, curve: Curves.easeIn),
  );

  @override
  void initState() {
    super.initState();
    _controller.forward();
    Future.delayed(const Duration(milliseconds: 2600), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          PageRouteBuilder(
            transitionDuration: const Duration(milliseconds: 600),
            pageBuilder: (_, anim, __) => const MainNavigation(),
            transitionsBuilder: (_, anim, __, child) => FadeTransition(opacity: anim, child: child),
          ),
        );
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.heroGradient),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedBuilder(
                animation: _controller,
                builder: (context, child) {
                  return Transform.translate(
                    offset: Offset(0, _bounce.value),
                    child: Transform.rotate(angle: _rotate.value, child: child),
                  );
                },
                child: _BasketballIcon(size: 110),
              ),
              const SizedBox(height: 28),
              FadeTransition(
                opacity: _fadeText,
                child: Column(
                  children: [
                    const Text(
                      'BASKETBALL\nAUSTRIA',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                        height: 1.15,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      width: 46,
                      height: 3,
                      decoration: BoxDecoration(
                        color: AppColors.accent,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'Die Heimat des österreichischen Basketballs',
                      style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Einfacher gezeichneter Basketball als Logo-Platzhalter (kein Asset nötig).
class _BasketballIcon extends StatelessWidget {
  final double size;
  const _BasketballIcon({required this.size});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _BasketballPainter()),
    );
  }
}

class _BasketballPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.width / 2;

    final ballPaint = Paint()
      ..shader = RadialGradient(
        colors: [AppColors.accentSoft, AppColors.accent],
        center: Alignment.topLeft,
      ).createShader(Rect.fromCircle(center: center, radius: radius));
    canvas.drawCircle(center, radius, ballPaint);

    final linePaint = Paint()
      ..color = Colors.black.withValues(alpha: 0.75)
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.028;

    canvas.drawLine(Offset(center.dx, 0), Offset(center.dx, size.height), linePaint);
    canvas.drawLine(Offset(0, center.dy), Offset(size.width, center.dy), linePaint);

    final rectV = Rect.fromCircle(center: center, radius: radius);
    canvas.drawArc(rectV.inflate(radius * 0.15), -math.pi / 3, math.pi * 2 / 3, false, linePaint);
    canvas.drawArc(rectV.inflate(radius * 0.15), math.pi - math.pi / 3, math.pi * 2 / 3, false, linePaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
