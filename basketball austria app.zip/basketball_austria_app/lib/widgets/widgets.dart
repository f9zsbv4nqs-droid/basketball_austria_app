import 'package:flutter/material.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';

/// Kreisförmiger Team-Logo-Platzhalter mit Initialen (kein echtes Bild nötig).
class TeamLogo extends StatelessWidget {
  final Team team;
  final double size;
  const TeamLogo({super.key, required this.team, this.size = 44});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          colors: [team.farbe, team.farbe.withValues(alpha: 0.55)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: team.farbe.withValues(alpha: 0.4),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      alignment: Alignment.center,
      child: Text(
        team.kurzname,
        style: TextStyle(
          fontSize: size * 0.32,
          fontWeight: FontWeight.w800,
          color: Colors.white,
        ),
      ),
    );
  }
}

/// Kreisförmiger Spielerfoto-Platzhalter mit Initialen.
class PlayerAvatar extends StatelessWidget {
  final Player player;
  final double size;
  const PlayerAvatar({super.key, required this.player, this.size = 56});

  @override
  Widget build(BuildContext context) {
    final initials = player.name
        .split(' ')
        .map((e) => e.isNotEmpty ? e[0] : '')
        .take(2)
        .join();
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: AppColors.accent, width: 2),
        color: AppColors.surfaceElevated,
      ),
      alignment: Alignment.center,
      child: Text(
        initials,
        style: TextStyle(
          fontSize: size * 0.34,
          fontWeight: FontWeight.w800,
          color: AppColors.accent,
        ),
      ),
    );
  }
}

/// Titel + optionaler "Alle anzeigen" Link für Sektionen im Home-Screen.
class SectionHeader extends StatelessWidget {
  final String title;
  final String? actionLabel;
  final VoidCallback? onAction;
  const SectionHeader({super.key, required this.title, this.actionLabel, this.onAction});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
        ),
        if (actionLabel != null)
          TextButton(
            onPressed: onAction,
            child: Text(
              actionLabel!,
              style: const TextStyle(color: AppColors.accent, fontWeight: FontWeight.w600),
            ),
          ),
      ],
    );
  }
}

/// Kleines pulsierendes "LIVE" Badge.
class LiveBadge extends StatefulWidget {
  const LiveBadge({super.key});
  @override
  State<LiveBadge> createState() => _LiveBadgeState();
}

class _LiveBadgeState extends State<LiveBadge> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.liveRed.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          FadeTransition(
            opacity: _controller,
            child: Container(
              width: 7,
              height: 7,
              decoration: const BoxDecoration(color: AppColors.liveRed, shape: BoxShape.circle),
            ),
          ),
          const SizedBox(width: 5),
          const Text(
            'LIVE',
            style: TextStyle(color: AppColors.liveRed, fontWeight: FontWeight.w800, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

/// Karte für ein Spiel im Spielplan / Home-Bereich.
class GameCard extends StatelessWidget {
  final Game game;
  final VoidCallback? onTap;
  const GameCard({super.key, required this.game, this.onTap});

  String _statusLabel() {
    switch (game.status) {
      case GameStatus.bevorstehend:
        final d = game.datum;
        return '${d.day}.${d.month}. · ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
      case GameStatus.live:
        return game.quarter;
      case GameStatus.beendet:
        return 'Beendet';
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLive = game.status == GameStatus.live;
    final isDone = game.status == GameStatus.beendet;
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          border: isLive ? Border.all(color: AppColors.liveRed.withValues(alpha: 0.4)) : null,
          boxShadow: cardShadow,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  game.halle,
                  style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                  overflow: TextOverflow.ellipsis,
                ),
                isLive
                    ? const LiveBadge()
                    : Text(
                        _statusLabel(),
                        style: TextStyle(
                          color: isDone ? AppColors.textSecondary : AppColors.accent,
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                        ),
                      ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: Row(
                    children: [
                      TeamLogo(team: game.heim, size: 36),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          game.heim.kurzname,
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  ),
                ),
                if (isLive || isDone)
                  Text(
                    '${game.heimScore}',
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
                  )
                else
                  const Text('vs', style: TextStyle(color: AppColors.textSecondary)),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: Row(
                    children: [
                      TeamLogo(team: game.gast, size: 36),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          game.gast.kurzname,
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  ),
                ),
                if (isLive || isDone)
                  Text(
                    '${game.gastScore}',
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
                  ),
              ],
            ),
            if (isLive) ...[
              const SizedBox(height: 12),
              Text(_statusLabel(), style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
            ]
          ],
        ),
      ),
    );
  }
}

/// Große News-Karte mit Bild-Platzhalter (Farbverlauf statt echtem Bild).
class NewsCard extends StatelessWidget {
  final NewsArticle article;
  final VoidCallback? onTap;
  const NewsCard({super.key, required this.article, this.onTap});

  Color _hex(String hex) => Color(int.parse(hex.replaceFirst('#', '0xFF')));

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: Container(
        height: 190,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          boxShadow: cardShadow,
          gradient: LinearGradient(
            colors: [_hex(article.bildFarbe1), _hex(article.bildFarbe2)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.35),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                article.kategorie,
                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
              ),
            ),
            const Spacer(),
            Text(
              article.titel,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, height: 1.2),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 6),
            Text(
              article.datum,
              style: const TextStyle(fontSize: 12, color: Colors.white70),
            ),
          ],
        ),
      ),
    );
  }
}

/// Spieler-Karte für Team-Kader und Top-Performer-Listen.
class PlayerCard extends StatelessWidget {
  final Player player;
  final VoidCallback? onTap;
  const PlayerCard({super.key, required this.player, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        width: 150,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(18),
          boxShadow: cardShadow,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                PlayerAvatar(player: player, size: 44),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '#${player.nummer}',
                    style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              player.name,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              player.team.kurzname,
              style: const TextStyle(color: AppColors.textSecondary, fontSize: 11),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _statMini('${player.ppg.toStringAsFixed(1)}', 'PTS'),
                _statMini('${player.rpg.toStringAsFixed(1)}', 'REB'),
                _statMini('${player.apg.toStringAsFixed(1)}', 'AST'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _statMini(String value, String label) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.accent, fontSize: 13)),
        Text(label, style: const TextStyle(fontSize: 9, color: AppColors.textSecondary)),
      ],
    );
  }
}

/// Zeile für eine Tabellenposition in der Ligen-Ansicht.
class TableRowWidget extends StatelessWidget {
  final StandingsRow row;
  final VoidCallback? onTap;
  const TableRowWidget({super.key, required this.row, this.onTap});

  @override
  Widget build(BuildContext context) {
    final top4 = row.team.tabellenplatz <= 4;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          border: Border(
            left: BorderSide(
              color: top4 ? AppColors.accent : Colors.transparent,
              width: 3,
            ),
          ),
        ),
        child: Row(
          children: [
            SizedBox(
              width: 24,
              child: Text(
                '${row.team.tabellenplatz}',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  color: top4 ? AppColors.accent : AppColors.textSecondary,
                ),
              ),
            ),
            const SizedBox(width: 8),
            TeamLogo(team: row.team, size: 32),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                row.team.name,
                style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            _col('${row.spiele}'),
            _col('${row.siege}'),
            _col('${row.niederlagen}'),
            SizedBox(
              width: 32,
              child: Text(
                '${row.punkte}',
                textAlign: TextAlign.right,
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _col(String value) => SizedBox(
        width: 28,
        child: Text(value, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
      );
}

/// Statistik-Kachel (z.B. PPG / RPG / APG) für Spielerprofil.
class StatTile extends StatelessWidget {
  final String value;
  final String label;
  const StatTile({super.key, required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
      ),
      alignment: Alignment.center,
      child: Column(
        children: [
          Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.accent)),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
        ],
      ),
    );
  }
}
