import 'package:flutter/material.dart';
import '../models/models.dart';

/// Zentrale Mock-Daten-Klasse. Keine echten APIs, keine echten Personen –
/// alle Namen sind frei erfundene, realistisch wirkende Platzhalter für
/// den Pitch-Prototyp der "Basketball Austria App".
class MockData {
  // ---------------------------------------------------------------------
  // TEAMS
  // ---------------------------------------------------------------------
  static final Team viennaTimberwolves = Team(
    id: 't1',
    name: 'Vienna Timberwolves',
    kurzname: 'VIE',
    stadt: 'Wien',
    farbe: const Color(0xFFFF8A00),
    arena: 'Donauhalle Wien',
    trainer: 'Markus Feldner',
    tabellenplatz: 1,
    liga: Liga.herren1,
  );

  static final Team kapfenbergBulls = Team(
    id: 't2',
    name: 'Kapfenberg Bulls',
    kurzname: 'KAP',
    stadt: 'Kapfenberg',
    farbe: const Color(0xFF3D8BFF),
    arena: 'Walzwerk Arena',
    trainer: 'Daniel Sattler',
    tabellenplatz: 2,
    liga: Liga.herren1,
  );

  static final Team grazEagles = Team(
    id: 't3',
    name: 'Graz Eagles',
    kurzname: 'GRZ',
    stadt: 'Graz',
    farbe: const Color(0xFF2ED573),
    arena: 'Sporthalle Graz-Liebenau',
    trainer: 'Thomas Wieser',
    tabellenplatz: 3,
    liga: Liga.herren1,
  );

  static final Team linzRiverKings = Team(
    id: 't4',
    name: 'Linz River Kings',
    kurzname: 'LIN',
    stadt: 'Linz',
    farbe: const Color(0xFFE94560),
    arena: 'Donauhalle Linz',
    trainer: 'Philipp Hofer',
    tabellenplatz: 4,
    liga: Liga.herren1,
  );

  static final Team salzburgLions = Team(
    id: 't5',
    name: 'Salzburg Lions',
    kurzname: 'SAL',
    stadt: 'Salzburg',
    farbe: const Color(0xFFB967FF),
    arena: 'Festungsarena',
    trainer: 'Andreas Kern',
    tabellenplatz: 5,
    liga: Liga.herren1,
  );

  static final Team innsbruckPeaks = Team(
    id: 't6',
    name: 'Innsbruck Peaks',
    kurzname: 'INN',
    stadt: 'Innsbruck',
    farbe: const Color(0xFF3DD9D6),
    arena: 'Bergisel Halle',
    trainer: 'Julian Mair',
    tabellenplatz: 6,
    liga: Liga.herren1,
  );

  // 2. Bundesliga Herren
  static final Team stpoeltenHawks = Team(
    id: 't7',
    name: 'St. Pölten Hawks',
    kurzname: 'STP',
    stadt: 'St. Pölten',
    farbe: const Color(0xFFFFC93C),
    arena: 'NV Arena Halle',
    trainer: 'Robert Gruber',
    tabellenplatz: 1,
    liga: Liga.herren2,
  );

  static final Team klagenfurtWolves = Team(
    id: 't8',
    name: 'Klagenfurt Wolves',
    kurzname: 'KLA',
    stadt: 'Klagenfurt',
    farbe: const Color(0xFF6C5CE7),
    arena: 'Wörtherseehalle',
    trainer: 'Michael Berger',
    tabellenplatz: 2,
    liga: Liga.herren2,
  );

  static final Team wienCapitals = Team(
    id: 't9',
    name: 'Wien Capitals',
    kurzname: 'WNC',
    stadt: 'Wien',
    farbe: const Color(0xFF00B4D8),
    arena: 'Ferry-Dusika-Halle',
    trainer: 'Christian Aigner',
    tabellenplatz: 3,
    liga: Liga.herren2,
  );

  static final Team villachSharks = Team(
    id: 't10',
    name: 'Villach Sharks',
    kurzname: 'VIL',
    stadt: 'Villach',
    farbe: const Color(0xFF00D9A3),
    arena: 'Draustadion Halle',
    trainer: 'Sebastian Moser',
    tabellenplatz: 4,
    liga: Liga.herren2,
  );

  // Damen Bundesliga
  static final Team viennaQueens = Team(
    id: 't11',
    name: 'Vienna Queens',
    kurzname: 'VIQ',
    stadt: 'Wien',
    farbe: const Color(0xFFFF6FA8),
    arena: 'Donauhalle Wien',
    trainer: 'Nina Holzer',
    tabellenplatz: 1,
    liga: Liga.damen,
  );

  static final Team grazPhoenix = Team(
    id: 't12',
    name: 'Graz Phoenix Ladies',
    kurzname: 'GRP',
    stadt: 'Graz',
    farbe: const Color(0xFFFF8A00),
    arena: 'Sporthalle Graz-Liebenau',
    trainer: 'Barbara Steiner',
    tabellenplatz: 2,
    liga: Liga.damen,
  );

  static final Team linzValkyries = Team(
    id: 't13',
    name: 'Linz Valkyries',
    kurzname: 'LIV',
    stadt: 'Linz',
    farbe: const Color(0xFF3D8BFF),
    arena: 'Donauhalle Linz',
    trainer: 'Julia Reiter',
    tabellenplatz: 3,
    liga: Liga.damen,
  );

  static final Team salzburgQueens = Team(
    id: 't14',
    name: 'Salzburg Queens',
    kurzname: 'SAQ',
    stadt: 'Salzburg',
    farbe: const Color(0xFF2ED573),
    arena: 'Festungsarena',
    trainer: 'Elisabeth Wagner',
    tabellenplatz: 4,
    liga: Liga.damen,
  );

  static List<Team> get alleTeams => [
        viennaTimberwolves,
        kapfenbergBulls,
        grazEagles,
        linzRiverKings,
        salzburgLions,
        innsbruckPeaks,
        stpoeltenHawks,
        klagenfurtWolves,
        wienCapitals,
        villachSharks,
        viennaQueens,
        grazPhoenix,
        linzValkyries,
        salzburgQueens,
      ];

  // ---------------------------------------------------------------------
  // TABELLEN
  // ---------------------------------------------------------------------
  static List<StandingsRow> tabelle(Liga liga) {
    final teams = alleTeams.where((t) => t.liga == liga).toList()
      ..sort((a, b) => a.tabellenplatz.compareTo(b.tabellenplatz));

    return teams.map((t) {
      final siege = 22 - (t.tabellenplatz * 2);
      final niederlagen = 6 + (t.tabellenplatz * 2);
      return StandingsRow(
        team: t,
        spiele: siege + niederlagen,
        siege: siege,
        niederlagen: niederlagen,
        punkte: siege * 2 + niederlagen,
      );
    }).toList();
  }

  // ---------------------------------------------------------------------
  // SPIELER
  // ---------------------------------------------------------------------
  static final Player lukasHofmann = Player(
    id: 'p1',
    name: 'Lukas Hofmann',
    position: 'Point Guard',
    team: viennaTimberwolves,
    nummer: 7,
    ppg: 22.4,
    rpg: 4.1,
    apg: 7.8,
    fgPercent: 48.2,
    minutes: 32.5,
    saisonverlauf: [18, 24, 20, 26, 19, 28, 22, 25, 21, 24],
  );

  static final Player davidWimmer = Player(
    id: 'p2',
    name: 'David Wimmer',
    position: 'Shooting Guard',
    team: viennaTimberwolves,
    nummer: 11,
    ppg: 18.9,
    rpg: 3.2,
    apg: 3.5,
    fgPercent: 44.7,
    minutes: 29.1,
    saisonverlauf: [15, 17, 19, 14, 22, 18, 20, 16, 19, 21],
  );

  static final Player marcusJefferson = Player(
    id: 'p3',
    name: 'Marcus Jefferson',
    position: 'Power Forward',
    team: kapfenbergBulls,
    nummer: 34,
    ppg: 20.1,
    rpg: 10.4,
    apg: 2.1,
    fgPercent: 52.8,
    minutes: 31.0,
    saisonverlauf: [16, 22, 24, 18, 20, 25, 19, 23, 21, 20],
  );

  static final Player florianEgger = Player(
    id: 'p4',
    name: 'Florian Egger',
    position: 'Center',
    team: grazEagles,
    nummer: 21,
    ppg: 16.3,
    rpg: 11.8,
    apg: 1.4,
    fgPercent: 55.1,
    minutes: 27.8,
    saisonverlauf: [12, 14, 18, 16, 15, 19, 17, 14, 16, 18],
  );

  static final Player tobiasReiter = Player(
    id: 'p5',
    name: 'Tobias Reiter',
    position: 'Small Forward',
    team: linzRiverKings,
    nummer: 9,
    ppg: 19.5,
    rpg: 5.6,
    apg: 4.2,
    fgPercent: 46.3,
    minutes: 30.2,
    saisonverlauf: [14, 20, 22, 18, 21, 17, 24, 19, 20, 22],
  );

  static final Player leonBrandner = Player(
    id: 'p6',
    name: 'Leon Brandner',
    position: 'Point Guard',
    team: salzburgLions,
    nummer: 3,
    ppg: 15.7,
    rpg: 3.9,
    apg: 6.5,
    fgPercent: 43.9,
    minutes: 28.4,
    saisonverlauf: [10, 15, 17, 14, 16, 18, 15, 17, 14, 16],
  );

  static List<Player> get alleSpieler => [
        lukasHofmann,
        davidWimmer,
        marcusJefferson,
        florianEgger,
        tobiasReiter,
        leonBrandner,
      ];

  static List<Player> topPerformer() => [
        lukasHofmann,
        marcusJefferson,
        tobiasReiter,
      ];

  static List<Player> spielerVonTeam(Team team) =>
      alleSpieler.where((p) => p.team.id == team.id).toList();

  // ---------------------------------------------------------------------
  // SPIELE
  // ---------------------------------------------------------------------
  static final Game topSpielHeute = Game(
    id: 'g1',
    heim: viennaTimberwolves,
    gast: kapfenbergBulls,
    datum: DateTime.now().add(const Duration(hours: 3)),
    halle: 'Donauhalle Wien',
    status: GameStatus.bevorstehend,
    liga: Liga.herren1,
  );

  static final Game liveSpiel = Game(
    id: 'g2',
    heim: grazEagles,
    gast: linzRiverKings,
    datum: DateTime.now(),
    halle: 'Sporthalle Graz-Liebenau',
    status: GameStatus.live,
    heimScore: 88,
    gastScore: 84,
    quarter: 'Q4 02:15',
    heimQuarterScores: [24, 20, 22, 22],
    gastQuarterScores: [18, 24, 20, 22],
    liga: Liga.herren1,
  );

  static final Game beendetesSpiel = Game(
    id: 'g3',
    heim: salzburgLions,
    gast: innsbruckPeaks,
    datum: DateTime.now().subtract(const Duration(days: 1)),
    halle: 'Festungsarena',
    status: GameStatus.beendet,
    heimScore: 91,
    gastScore: 79,
    quarter: 'Endstand',
    heimQuarterScores: [22, 24, 23, 22],
    gastQuarterScores: [18, 20, 19, 22],
    liga: Liga.herren1,
  );

  static final Game wochenSpiel1 = Game(
    id: 'g4',
    heim: stpoeltenHawks,
    gast: klagenfurtWolves,
    datum: DateTime.now().add(const Duration(days: 2, hours: 5)),
    halle: 'NV Arena Halle',
    status: GameStatus.bevorstehend,
    liga: Liga.herren2,
  );

  static final Game wochenSpiel2 = Game(
    id: 'g5',
    heim: viennaQueens,
    gast: grazPhoenix,
    datum: DateTime.now().add(const Duration(days: 3, hours: 2)),
    halle: 'Donauhalle Wien',
    status: GameStatus.bevorstehend,
    liga: Liga.damen,
  );

  static final Game playoffSpiel = Game(
    id: 'g6',
    heim: wienCapitals,
    gast: villachSharks,
    datum: DateTime.now().add(const Duration(days: 14)),
    halle: 'Ferry-Dusika-Halle',
    status: GameStatus.bevorstehend,
    liga: Liga.herren2,
  );

  static List<Game> get alleSpiele => [
        topSpielHeute,
        liveSpiel,
        beendetesSpiel,
        wochenSpiel1,
        wochenSpiel2,
        playoffSpiel,
      ];

  static List<Game> spielplanVonTeam(Team team) => alleSpiele
      .where((g) => g.heim.id == team.id || g.gast.id == team.id)
      .toList();

  // ---------------------------------------------------------------------
  // NEWS
  // ---------------------------------------------------------------------
  static final List<NewsArticle> news = [
    const NewsArticle(
      id: 'n1',
      titel: 'Vienna Timberwolves sichern sich Playoff-Platz',
      kategorie: '1. Bundesliga',
      bildFarbe1: '#FF8A00',
      bildFarbe2: '#1B2233',
      zusammenfassung:
          'Mit einem klaren Auswärtssieg fixieren die Timberwolves vorzeitig den Einzug in die Playoffs und untermauern ihre Titelambitionen.',
      datum: 'vor 2 Std.',
    ),
    const NewsArticle(
      id: 'n2',
      titel: 'Kapfenberg verpflichtet US-Guard',
      kategorie: 'Transfers',
      bildFarbe1: '#3D8BFF',
      bildFarbe2: '#0B0F19',
      zusammenfassung:
          'Die Bulls verstärken sich kurz vor Saisonende mit einem erfahrenen amerikanischen Aufbauspieler für den Playoff-Endspurt.',
      datum: 'vor 5 Std.',
    ),
    const NewsArticle(
      id: 'n3',
      titel: 'Österreichisches Talent debütiert',
      kategorie: 'Nachwuchs',
      bildFarbe1: '#2ED573',
      bildFarbe2: '#141926',
      zusammenfassung:
          'Ein 18-jähriger Nachwuchsspieler feiert sein Debüt in der Bundesliga und überzeugt direkt mit einer starken Leistung.',
      datum: 'gestern',
    ),
    const NewsArticle(
      id: 'n4',
      titel: 'Graz Eagles verlängern mit Kapitän',
      kategorie: '1. Bundesliga',
      bildFarbe1: '#B967FF',
      bildFarbe2: '#141926',
      zusammenfassung:
          'Die Eagles setzen auf Kontinuität und verlängern den Vertrag mit ihrem langjährigen Mannschaftskapitän um zwei weitere Jahre.',
      datum: 'vor 1 Tag',
    ),
    const NewsArticle(
      id: 'n5',
      titel: 'Damen Bundesliga: Vienna Queens auf Titelkurs',
      kategorie: 'Damen Bundesliga',
      bildFarbe1: '#FF6FA8',
      bildFarbe2: '#0B0F19',
      zusammenfassung:
          'Die Vienna Queens bleiben nach dem neunten Sieg in Serie an der Tabellenspitze und gelten als Top-Favorit auf den Meistertitel.',
      datum: 'vor 1 Tag',
    ),
  ];
}
