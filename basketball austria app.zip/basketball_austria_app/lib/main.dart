import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'screens/splash_screen.dart';

void main() {
  runApp(const BasketballAustriaApp());
}

/// Basketball Austria App – Interaktiver MVP Pitch-Prototyp.
/// Zentrale Plattform für 1. Bundesliga Herren, 2. Bundesliga Herren
/// und Damen Bundesliga. Ausschließlich Mock-Daten, kein Backend.
class BasketballAustriaApp extends StatelessWidget {
  const BasketballAustriaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Basketball Austria',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.dark,
      home: const SplashScreen(),
    );
  }
}
