import 'package:flutter/material.dart';

/// Liga-Kategorien der österreichischen Basketball-App.
enum Liga { herren1, herren2, damen }

extension LigaLabel on Liga {
  String get label {
    switch (this) {
      case Liga.herren1:
        return '1. Bundesliga Herren';
      case Liga.herren2:
        return '2. Bundesliga Herren';
      case Liga.damen:
        return 'Damen Bundesliga';
    }
  }
}

enum GameStatus { bevorstehend, live, beendet }

/// Repräsentiert ein Team der österreichischen Basketballliga (Mock).
class Team {
  final String id;
  final String name;
  final String kurzname;
  final String stadt;
  final Color farbe;
  final String arena;
  final String trainer;
  final int tabellenplatz;
  final Liga liga;

  const Team({
    required this.id,
    required this.name,
    required this.kurzname,
    required this.stadt,
    required this.farbe,
    required this.arena,
    required this.trainer,
    required this.tabellenplatz,
    required this.liga,
  });
}

/// Tabellenzeile einer Liga.
class StandingsRow {
  final Team team;
  final int spiele;
  final int siege;
  final int niederlagen;
  final int punkte;

  const StandingsRow({
    required this.team,
    required this.spiele,
    required this.siege,
    required this.niederlagen,
    required this.punkte,
  });
}

/// Spieler-Profil mit Statistiken (Mock).
class Player {
  final String id;
  final String name;
  final String position;
  final Team team;
  final int nummer;
  final double ppg;
  final double rpg;
  final double apg;
  final double fgPercent;
  final double minutes;
  final List<double> saisonverlauf; // Punkte je Spiel für Grafik

  const Player({
    required this.id,
    required this.name,
    required this.position,
    required this.team,
    required this.nummer,
    required this.ppg,
    required this.rpg,
    required this.apg,
    required this.fgPercent,
    required this.minutes,
    required this.saisonverlauf,
  });
}

/// Einzelnes Spiel im Spielplan / Live-Bereich.
class Game {
  final String id;
  final Team heim;
  final Team gast;
  final DateTime datum;
  final String halle;
  final GameStatus status;
  final int heimScore;
  final int gastScore;
  final String quarter;
  final List<int> heimQuarterScores;
  final List<int> gastQuarterScores;
  final Liga liga;

  const Game({
    required this.id,
    required this.heim,
    required this.gast,
    required this.datum,
    required this.halle,
    required this.status,
    this.heimScore = 0,
    this.gastScore = 0,
    this.quarter = '',
    this.heimQuarterScores = const [],
    this.gastQuarterScores = const [],
    required this.liga,
  });
}

/// News-Artikel für den News-Bereich.
class NewsArticle {
  final String id;
  final String titel;
  final String kategorie;
  final String bildFarbe1;
  final String bildFarbe2;
  final String zusammenfassung;
  final String datum;

  const NewsArticle({
    required this.id,
    required this.titel,
    required this.kategorie,
    required this.bildFarbe1,
    required this.bildFarbe2,
    required this.zusammenfassung,
    required this.datum,
  });
}
